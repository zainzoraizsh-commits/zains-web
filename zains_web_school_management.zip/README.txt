SCHOOL MANAGEMENT WEBSITE
==========================

Files:
- index.html      -> Dashboard
- students.html   -> Add/edit/delete student records
- fees.html       -> Manage paid/pending fees
- style.css       -> Website design
- script.js       -> JavaScript functionality

HOW TO RUN:
1. Put all files in the same folder.
2. Open index.html in Chrome/Edge/Firefox.
3. No server or installation is required.

FEATURES:
- 3 pages
- Student name, roll number, class, phone and monthly fee
- Paid/Pending fee status
- Add, edit and delete students
- Search students
- Dashboard statistics
- Responsive/mobile-friendly layout
- Data saved in browser localStorage

NOTE:
This is a front-end project. Records are saved only in the browser/device where you use it.
