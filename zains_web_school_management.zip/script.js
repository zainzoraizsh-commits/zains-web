const KEY="schoolManagerStudents";

function getStudents(){
  try{return JSON.parse(localStorage.getItem(KEY))||[]}
  catch(e){return []}
}
function saveStudents(data){localStorage.setItem(KEY,JSON.stringify(data))}
function money(n){return "Rs. "+Number(n||0).toLocaleString("en-PK")}
function setDate(){
  const el=document.getElementById("today");
  if(el) el.textContent=new Date().toLocaleDateString("en-PK",{weekday:"short",day:"numeric",month:"short",year:"numeric"});
}
function toggleSidebar(){document.querySelector(".sidebar")?.classList.toggle("open")}

function seed(){
  if(localStorage.getItem(KEY)===null){
    saveStudents([
      {id:Date.now()+1,name:"Ali Ahmed",roll:"101",className:"9th A",phone:"0300-1111111",fee:2500,status:"Paid"},
      {id:Date.now()+2,name:"Hassan Khan",roll:"102",className:"9th A",phone:"0301-2222222",fee:2500,status:"Pending"},
      {id:Date.now()+3,name:"Ayesha Noor",roll:"103",className:"8th B",phone:"0302-3333333",fee:2200,status:"Paid"}
    ]);
  }
}

function badge(status){return `<span class="badge ${status==="Paid"?"paid":"pending"}">${status}</span>`}

function renderDashboard(){
  const students=getStudents();
  const paid=students.filter(s=>s.status==="Paid");
  const pending=students.filter(s=>s.status==="Pending");
  const collected=paid.reduce((a,s)=>a+Number(s.fee||0),0);
  document.getElementById("totalStudents")&&(document.getElementById("totalStudents").textContent=students.length);
  document.getElementById("feesPaid")&&(document.getElementById("feesPaid").textContent=paid.length);
  document.getElementById("feesPending")&&(document.getElementById("feesPending").textContent=pending.length);
  document.getElementById("totalCollected")&&(document.getElementById("totalCollected").textContent=money(collected));
  const tbody=document.getElementById("recentStudents");
  if(tbody){
    const recent=[...students].reverse().slice(0,6);
    tbody.innerHTML=recent.length?recent.map(s=>`<tr><td>${escapeHTML(s.roll)}</td><td><b>${escapeHTML(s.name)}</b></td><td>${escapeHTML(s.className)}</td><td>${badge(s.status)}</td></tr>`).join(""):`<tr><td class="empty" colspan="4">No students added yet.</td></tr>`;
  }
}

function renderStudents(){
  const tbody=document.getElementById("studentTable"); if(!tbody)return;
  const query=(document.getElementById("studentSearch")?.value||"").toLowerCase();
  const all=getStudents();
  const students=all.filter(s=>(s.name+" "+s.roll+" "+s.className).toLowerCase().includes(query));
  document.getElementById("studentCount").textContent=`${all.length} student${all.length!==1?"s":""}`;
  tbody.innerHTML=students.length?students.map(s=>`<tr>
    <td><b>${escapeHTML(s.roll)}</b></td><td>${escapeHTML(s.name)}</td><td>${escapeHTML(s.className)}</td>
    <td>${escapeHTML(s.phone||"-")}</td><td>${money(s.fee)}</td><td>${badge(s.status)}</td>
    <td><div class="actions"><button class="action edit" onclick="editStudent(${s.id})">Edit</button><button class="action delete" onclick="deleteStudent(${s.id})">Delete</button></div></td>
  </tr>`).join(""):`<tr><td class="empty" colspan="7">No matching students found.</td></tr>`;
}

function escapeHTML(v){
  return String(v??"").replace(/[&<>"']/g,m=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#039;"}[m]));
}

function resetForm(){
  document.getElementById("studentForm")?.reset();
  document.getElementById("studentId").value="";
  document.getElementById("formTitle").textContent="Add New Student";
  document.getElementById("saveBtn").textContent="Save Student";
}

function editStudent(id){
  const s=getStudents().find(x=>x.id===id); if(!s)return;
  document.getElementById("studentId").value=s.id;
  document.getElementById("name").value=s.name;
  document.getElementById("roll").value=s.roll;
  document.getElementById("className").value=s.className;
  document.getElementById("phone").value=s.phone||"";
  document.getElementById("fee").value=s.fee;
  document.getElementById("status").value=s.status;
  document.getElementById("formTitle").textContent="Edit Student";
  document.getElementById("saveBtn").textContent="Update Student";
  window.scrollTo({top:0,behavior:"smooth"});
}

function deleteStudent(id){
  if(!confirm("Delete this student record?"))return;
  saveStudents(getStudents().filter(s=>s.id!==id));
  renderStudents(); renderFees(); renderDashboard();
}

function handleForm(e){
  e.preventDefault();
  const id=document.getElementById("studentId").value;
  const student={
    id:id?Number(id):Date.now(),
    name:document.getElementById("name").value.trim(),
    roll:document.getElementById("roll").value.trim(),
    className:document.getElementById("className").value.trim(),
    phone:document.getElementById("phone").value.trim(),
    fee:Number(document.getElementById("fee").value),
    status:document.getElementById("status").value
  };
  const students=getStudents();
  const duplicate=students.find(s=>s.roll===student.roll && s.id!==student.id);
  if(duplicate){alert("That roll number is already in use.");return}
  if(id){saveStudents(students.map(s=>s.id===student.id?student:s))}
  else{students.push(student);saveStudents(students)}
  resetForm(); renderStudents(); renderFees(); renderDashboard();
  alert(id?"Student updated successfully!":"Student added successfully!");
}

function renderFees(){
  const tbody=document.getElementById("feeTable"); if(!tbody)return;
  const all=getStudents(), q=(document.getElementById("feeSearch")?.value||"").toLowerCase();
  const students=all.filter(s=>(s.name+" "+s.roll+" "+s.className).toLowerCase().includes(q));
  const paid=all.filter(s=>s.status==="Paid"), pending=all.filter(s=>s.status==="Pending");
  document.getElementById("paidCount").textContent=paid.length;
  document.getElementById("pendingCount").textContent=pending.length;
  document.getElementById("collectedAmount").textContent=money(paid.reduce((a,s)=>a+Number(s.fee||0),0));
  tbody.innerHTML=students.length?students.map(s=>`<tr><td><b>${escapeHTML(s.roll)}</b></td><td>${escapeHTML(s.name)}</td><td>${escapeHTML(s.className)}</td><td>${money(s.fee)}</td><td>${badge(s.status)}</td><td><select class="select-status" onchange="updateFee(${s.id},this.value)"><option ${s.status==="Paid"?"selected":""}>Paid</option><option ${s.status==="Pending"?"selected":""}>Pending</option></select></td></tr>`).join(""):`<tr><td class="empty" colspan="6">No students found.</td></tr>`;
}

function updateFee(id,status){
  saveStudents(getStudents().map(s=>s.id===id?{...s,status}:s));
  renderFees(); renderDashboard();
}

document.addEventListener("DOMContentLoaded",()=>{
  seed(); setDate(); renderDashboard(); renderStudents(); renderFees();
  document.getElementById("studentForm")?.addEventListener("submit",handleForm);
  document.getElementById("studentSearch")?.addEventListener("input",renderStudents);
  document.getElementById("feeSearch")?.addEventListener("input",renderFees);
});
